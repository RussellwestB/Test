from distutils.core import setup

setup(name="wangru", version="1.0", description="wangru's module", author="wangru", py_modules=["testMsg.sendMsg", "testMsg.recvMsg"])
