def test1():
    print("sendMsg---test1---")


def test2():
    print("sendMsg---test2---")



